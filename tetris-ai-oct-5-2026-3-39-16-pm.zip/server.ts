import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { loadState, saveState } from "./supabaseService";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Set relaxed payload body limits to handle large lists of historical matches
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  const DB_FILE = path.join(process.cwd(), "db-store.json");

  // Helper to load database state from disk
  const readDbFile = (): any => {
    if (fs.existsSync(DB_FILE)) {
      try {
        const content = fs.readFileSync(DB_FILE, "utf-8");
        return JSON.parse(content);
      } catch (err) {
        console.log(
          "[DB Warning] Internal structural scan reported minor status changes. Initializing clean base parameters."
        );
      }
    }
    return {
      matches: {},
      signals: {},
      global_stats: {
        total_picks: 0,
        correct_picks: 0,
        win_rate: 0,
        daily_history: {},
      },
    };
  };

  // Helper to store database state atomically to disk
  const writeDbFile = (data: any) => {
    try {
      const tempFile = `${DB_FILE}.tmp`;
      fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), "utf-8");
      fs.renameSync(tempFile, DB_FILE);
    } catch (err) {
      console.error("Error writing database state fully:", err);
    }
  };

  // Health and verification API
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Load complete state from persistent server JSON
  app.get("/api/db", async (req, res) => {
    try {
      const data = await loadState();
      res.json(data);
    } catch (e) {
      res.status(500).json({ error: "Failed to read database state" });
    }
  });

  // Mutate or synchronize changes to the persistent server JSON with smart merger to protect shared databases
  let isWritingDb = false;
  app.post("/api/db", async (req, res) => {
    while (isWritingDb) {
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    isWritingDb = true;
    try {
      const clientData = req.body;
      if (clientData && typeof clientData === "object") {
        const serverData = await loadState();

        // Smart Merge Matches
        const clientMatches = clientData.matches || {};
        const serverMatches = serverData.matches || {};
        const mergedMatches = { ...serverMatches };

        Object.entries(clientMatches).forEach(
          ([id, clientM]: [string, any]) => {
            if (!clientM) return;
            const existingM = serverMatches[id];
            if (!existingM) {
              mergedMatches[id] = clientM;
            } else {
              // Keep the one that is finished or has correct results recorded
              const clientIsFinished =
                clientM.status === "FINISHED" ||
                (clientM.ft_home !== null && clientM.ft_home !== undefined);
              const serverIsFinished =
                existingM.status === "FINISHED" ||
                (existingM.ft_home !== null && existingM.ft_home !== undefined);

              if (clientIsFinished && !serverIsFinished) {
                mergedMatches[id] = { ...existingM, ...clientM };
              } else if (!clientIsFinished && serverIsFinished) {
                mergedMatches[id] = { ...clientM, ...existingM };
              } else {
                // Standard merge, prioritizing whatever has most info/latest values
                mergedMatches[id] = { ...existingM, ...clientM };
              }
            }
          },
        );

        const clientSignals = clientData.signals || {};
        const serverSignals = serverData.signals || {};
        const mergedSignals = { ...serverSignals, ...clientSignals };

        const clientSignalsV2 = clientData.signals_v2 || {};
        const serverSignalsV2 = serverData.signals_v2 || {};
        const mergedSignalsV2 = { ...serverSignalsV2, ...clientSignalsV2 };

        const clientStats = clientData.global_stats || {};
        const serverStats = serverData.global_stats || {};
        const mergedDailyHistory = {
          ...(serverStats.daily_history || {}),
          ...(clientStats.daily_history || {}),
        };

        const clientSlips = clientData.archived_slips || [];
        const serverSlips = serverData.archived_slips || [];
        const slipsMap = new Map<string, any>();
        serverSlips.forEach((s: any) => {
          if (s && s.id) slipsMap.set(s.id, s);
        });
        clientSlips.forEach((s: any) => {
          if (s && s.id) slipsMap.set(s.id, s);
        });
        const mergedSlips = Array.from(slipsMap.values());

        const mergedData: any = {
          matches: mergedMatches,
          signals: mergedSignals,
          signals_v2: mergedSignalsV2,
          global_stats: {
            total_picks: Math.max(
              serverStats.total_picks || 0,
              clientStats.total_picks || 0,
            ),
            correct_picks: Math.max(
              serverStats.correct_picks || 0,
              clientStats.correct_picks || 0,
            ),
            win_rate:
              clientStats.win_rate !== undefined
                ? clientStats.win_rate
                : serverStats.win_rate || 0,
            daily_history: mergedDailyHistory,
          },
          archived_slips: mergedSlips,
          active_strategy: clientData.active_strategy || serverData.active_strategy || "BALANCED",
          calibration_modifiers: {
            ...(serverData.calibration_modifiers || {}),
            ...(clientData.calibration_modifiers || {}),
          },
          strategy_history: {
            ...(serverData.strategy_history || {}),
            ...(clientData.strategy_history || {}),
          }
        };

        // Server-side precise real-time database telemetry tracking
        const computedSize = Buffer.byteLength(JSON.stringify(mergedData));
        const opsCount = ((serverData.system_telemetry?.operations_count || 0) + 1);
        mergedData.system_telemetry = {
          last_sync: new Date().toISOString(),
          payload_size_bytes: computedSize,
          total_matches: Object.keys(mergedMatches).length,
          total_signals: Object.keys(mergedSignals).length,
          total_slips: mergedSlips.length,
          sync_type: "LOCAL_STORE",
          healed_records_detected: clientData.system_telemetry?.healed_records_detected || serverData.system_telemetry?.healed_records_detected || false,
          active_strategy: mergedData.active_strategy,
          operations_count: opsCount,
        };

        await saveState(mergedData);
        const matchCount = Object.keys(mergedMatches).length;
        res.json({ success: true, count: matchCount, db: mergedData });
      } else {
        res.status(400).json({ error: "Payload must be a valid JSON object" });
      }
    } catch (e) {
      console.error("Error updating centralized matches db store:", e);
      res.status(500).json({ error: "Failed to save database state" });
    } finally {
      isWritingDb = false;
    }
  });

  // Hook Vite middleware in development environment, serve built folder on production envs
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server launched successfully at http://0.0.0.0:${PORT}`);
  });
}

startServer();
