import {
  collection,
  doc,
  getDocs,
  setDoc,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Match, OracleDatabase } from '../types';

export class FirestoreStorage {
  private static sanitizeDocId(id: string): string {
    return id.replace(/[\/\#\$\.\[\]\s\:]/g, '_').slice(0, 120);
  }

  /**
   * Cleans an object to ensure no undefined values are passed to Firestore.
   */
  private static cleanForFirestore(obj: any): any {
    if (obj === null || obj === undefined) return null;
    if (typeof obj !== 'object') return obj;
    if (Array.isArray(obj)) return obj.map((item) => this.cleanForFirestore(item));

    const cleaned: Record<string, any> = {};
    for (const [key, val] of Object.entries(obj)) {
      if (val !== undefined) {
        cleaned[key] = this.cleanForFirestore(val);
      }
    }
    return cleaned;
  }

  /**
   * Loads all matches directly from persistent Firestore cloud storage.
   */
  static async loadAllMatchesFromCloud(): Promise<Record<string, Match> | null> {
    try {
      const matchesCol = collection(db, 'matches');
      const snapshot = await getDocs(matchesCol);

      if (snapshot.empty) {
        return null;
      }

      const matches: Record<string, Match> = {};
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as Match;
        if (data && data.match_id) {
          matches[data.match_id] = data;
        }
      });

      console.log(`☁️ [Firestore Cloud] Successfully loaded ${Object.keys(matches).length} matches from permanent database.`);
      return matches;
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'matches');
      return null;
    }
  }

  /**
   * Persists matches to permanent Firestore cloud storage in batches.
   */
  static async saveMatchesToCloud(matches: Record<string, Match>): Promise<boolean> {
    try {
      const matchEntries = Object.values(matches || {});
      if (matchEntries.length === 0) return true;

      // Prioritize upcoming matches and recent settled fixtures (up to 600 matches)
      // to strictly preserve Firestore daily write quota while keeping active games synced
      const upcoming = matchEntries.filter((m) => m.status === 'UPCOMING');
      const finished = matchEntries
        .filter((m) => m.status === 'FINISHED')
        .sort((a, b) => (b.__parsedTime || 0) - (a.__parsedTime || 0));
      const syncTarget = [...upcoming, ...finished.slice(0, 600)];

      const BATCH_SIZE = 300;
      for (let i = 0; i < syncTarget.length; i += BATCH_SIZE) {
        const batch = writeBatch(db);
        const chunk = syncTarget.slice(i, i + BATCH_SIZE);

        chunk.forEach((m) => {
          if (!m.match_id) return;
          const docId = this.sanitizeDocId(m.match_id);
          const docRef = doc(db, 'matches', docId);
          const cleaned = this.cleanForFirestore({
            ...m,
            updated_at: new Date().toISOString(),
          });
          batch.set(docRef, cleaned, { merge: true });
        });

        await batch.commit();
      }

      // Also update system_meta
      try {
        const metaRef = doc(db, 'system_meta', 'global_state');
        await setDoc(
          metaRef,
          {
            id: 'global_state',
            total_matches: matchEntries.length,
            synced_cloud_matches: syncTarget.length,
            last_sync: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
          { merge: true }
        );
      } catch (metaErr) {
        // Meta document is non-blocking
      }

      console.log(`☁️ [Firestore Cloud] Successfully saved active matches (${syncTarget.length} synced, ${matchEntries.length} total) to permanent cloud database.`);
      return true;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'matches');
      return false;
    }
  }

  /**
   * Two-way intelligent merge between local matches and Firestore cloud matches.
   * Preserves historical matches, settled scores, and never deletes existing records.
   */
  static async syncAndMergeWithCloud(
    localMatches: Record<string, Match>
  ): Promise<Record<string, Match>> {
    try {
      const cloudMatches = await this.loadAllMatchesFromCloud();

      // If cloud has matches, merge them with local
      const merged: Record<string, Match> = { ...(cloudMatches || {}) };

      // Incorporate local matches into merged set
      let newOrUpdatedCount = 0;
      Object.entries(localMatches).forEach(([id, localM]) => {
        const existingCloudM = merged[id];
        if (!existingCloudM) {
          merged[id] = localM;
          newOrUpdatedCount++;
        } else {
          // If local has finished scores and cloud doesn't, or vice-versa, keep finished
          const localFinished = localM.status === 'FINISHED' && localM.ft_home !== null;
          const cloudFinished = existingCloudM.status === 'FINISHED' && existingCloudM.ft_home !== null;

          if (localFinished && !cloudFinished) {
            merged[id] = { ...existingCloudM, ...localM };
            newOrUpdatedCount++;
          }
        }
      });

      // If there were any matches in local that cloud didn't have or vice-versa, save back to cloud
      if (newOrUpdatedCount > 0 || !cloudMatches) {
        // Run save asynchronously in background
        this.saveMatchesToCloud(merged).catch((err) => {
          console.warn('Background cloud sync note:', err);
        });
      }

      return merged;
    } catch (err) {
      console.warn('Sync with cloud encountered fallback:', err);
      return localMatches;
    }
  }
}
