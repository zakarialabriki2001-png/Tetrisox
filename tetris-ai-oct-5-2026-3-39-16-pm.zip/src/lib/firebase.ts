import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  writeBatch,
  query,
  limit
} from 'firebase/firestore';
import { getAuth, signInAnonymously } from 'firebase/auth';

export const firebaseConfig = {
  projectId: "giga-path-2tgzl",
  appId: "1:518570644400:web:5d29088e0f0c9107a53c75",
  apiKey: "AIzaSyC59sqnvYArqJ0m9xzFSzddSFOaiPwmdLA",
  authDomain: "giga-path-2tgzl.firebaseapp.com",
  firestoreDatabaseId: "ai-studio-tetrisai-b8d148fd-3532-4adb-80d5-30d141e347eb",
  storageBucket: "giga-path-2tgzl.firebasestorage.app",
  messagingSenderId: "518570644400",
  measurementId: "",
  oAuthClientId: "518570644400-j3o19dh2jtutfg3kkdmjh6a67197rui5.apps.googleusercontent.com",
  recaptchaSiteKey: ""
};

// Initialize or reuse Firebase App instance
export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

// Initialize Firestore with the dedicated multi-database ID provisioned
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');

// Auto sign-in anonymously for security rules compliance
if (typeof window !== 'undefined') {
  signInAnonymously(auth).catch((err) => {
    console.warn('Anonymous auth note (fallback open rules active):', err?.message || err);
  });
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  return errInfo;
}
